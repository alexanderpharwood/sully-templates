function ExampleMiddleware(){

        this.run = function (request) {
            //
        }

}

Sully.registerMiddleware('example', new ExampleMiddleware());
