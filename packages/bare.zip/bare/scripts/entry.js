window.onload = function(){

    Sully.init({
        container: "Sully",
        exceptionMessage: "Oops, we've had a spillage!",
    });

};
